-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `bnum` int NOT NULL AUTO_INCREMENT,
  `mnum` int NOT NULL,
  `btitle` varchar(100) DEFAULT NULL,
  `bcontent` varchar(5000) DEFAULT NULL,
  `blocation` varchar(150) DEFAULT NULL,
  `bsnapshoturl` varchar(150) DEFAULT NULL,
  `bimgurl` varchar(150) DEFAULT NULL,
  `bdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `mid` varchar(32) DEFAULT NULL,
  `bview` int DEFAULT NULL,
  PRIMARY KEY (`bnum`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (0,0,'안녕하세요','hi','https://www.google.com/maps/search/?api=1&query=37.3028447%2C126.8665333&query_place_id=ChIJc6YZ6ypvezURxSgC8-6dNOk','https://maps.googleapis.com/maps/api/staticmap?center=37.3028447%2C126.8665333&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk','file:/C:/JAVAlibrary/img/test20220415_095110.jpg','2022-04-21 16:34:43','test',128),(3,0,'2빠','하이핼로우안녕 제니퍼야','https://www.google.com/maps/search/?api=1&query=40.6413113%2C-73.7781383&query_place_id=ChIJR0lA1VBmwokR8BGfSBOyT-w','https://maps.googleapis.com/maps/api/staticmap?center=40.6413113%2C-73.7781383&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk','file:/C:/JAVAlibrary/img/test20220414_180430.jpg','2022-04-21 16:35:56','test',224),(4,0,'wc4rytunkmui,o\'poi;iuytr','ad gfdgfhjhklkl\np][p\'ouiytrew','https://www.google.com/maps/search/?api=1&query=40.6413113%2C-73.7781383&query_place_id=ChIJR0lA1VBmwokR8BGfSBOyT-w','https://maps.googleapis.com/maps/api/staticmap?center=40.6413113%2C-73.7781383&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk','file:/C:/JAVAlibrary/img/test게시판%20본문보기%20형태.png','2022-04-21 16:43:49','test',34),(5,0,'1빠','ad gfdgfhjhklkl\np][p\'ouiytrew','https://www.google.com/maps/search/?api=1&query=37.3591784%2C127.1048319&query_place_id=ChIJU7UryTVYezURZpD6lMctDZM','https://maps.googleapis.com/maps/api/staticmap?center=37.3591784%2C127.1048319&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk','file:/C:/JAVAlibrary/img/test20220415_194039.jpg','2022-04-21 17:12:11','godoklife',679),(8,0,'이미지 없이 등록한 글','하지만 지도를 끼얹은','https://www.google.com/maps/search/?api=1&query=37.300907%2C126.7353972&query_place_id=ChIJ7UXJG5BzezURLJ_KnmuRXAQ','https://maps.googleapis.com/maps/api/staticmap?center=37.300907%2C126.7353972&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk',NULL,'2022-04-21 22:06:42','godoklife',35),(9,0,'njlk;lljkghdfg','rhyjkjlk/.kyjhgfwwesfgnn',NULL,NULL,NULL,'2022-04-22 15:55:49','유재석',24),(10,0,'rwetrstdyluh','wwafefcvhbjl',NULL,NULL,NULL,'2022-04-22 15:55:58','asdf',2),(11,0,'werrytkuyluiokjnhbvfbdvf','xzcbnvb,./k;?.iyujthrgf',NULL,NULL,NULL,'2022-04-22 15:56:04','asdf',57),(13,0,',mjhgrfgb nm,loi','uytfvb n,lkjuhgvb ',NULL,NULL,NULL,'2022-04-22 15:56:15','asdf',3),(14,0,'2wedfgytr','fvghytfvgbn',NULL,NULL,NULL,'2022-04-22 15:56:22','ㅁㄴㅇ',23),(15,0,'안녕하세요','인천공항입니다	','https://www.google.com/maps/search/?api=1&query=37.4493722%2C126.4513555&query_place_id=ChIJyRylLtGbezUROr4tSjITk1c','https://maps.googleapis.com/maps/api/staticmap?center=37.4493722%2C126.4513555&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk','file:/C:/JAVAlibrary/img/testtestpizza.jpg','2022-04-25 17:08:01','미니이리',3),(16,0,'assdfghjkl;l;','sadfghfui\n;]\'','https://www.google.com/maps/search/?api=1&query=40.6413113%2C-73.7781383&query_place_id=ChIJR0lA1VBmwokR8BGfSBOyT-w','https://maps.googleapis.com/maps/api/staticmap?center=40.6413113%2C-73.7781383&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk','file:/C:/JAVAlibrary/img/testtestpizza.jpg','2022-04-25 17:23:15','틀',8),(17,0,'웹 검색','검색할거야','https://www.google.com/maps/search/?api=1&query=51.5072178%2C-0.1275862&query_place_id=ChIJdd4hrwug2EcRmSrV3Vo6llI','https://maps.googleapis.com/maps/api/staticmap?center=51.5072178%2C-0.1275862&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk','file:/C:/Users/504/front/src/main/webapp/3.WEPPAGE/5_WEB/img/캐러셀1.jpg','2022-04-27 11:20:55','test',1),(18,0,'ㅁㄴㅇㄴㅁ','ㅇㄴㅁㅇㄴㅁㅇ','https://www.google.com/maps/search/?api=1&query=55.378051%2C-3.435973&query_place_id=ChIJqZHHQhE7WgIReiWIMkOg-MQ','https://maps.googleapis.com/maps/api/staticmap?center=55.378051%2C-3.435973&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk',NULL,'2022-04-27 11:21:37','test',1),(19,0,'아이스크림','아이스크림 맛있어','https://www.google.com/maps/search/?api=1&query=40.7127753%2C-74.0059728&query_place_id=ChIJOwg_06VPwokRYv534QaPC8g','https://maps.googleapis.com/maps/api/staticmap?center=40.7127753%2C-74.0059728&zoom=12&size=400x400&key=AIzaSyBcCZWS-wZM0meHcPuZuysyK4B3yquZ3Mk',NULL,'2022-04-27 12:22:20','test',1);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-27 13:44:44
